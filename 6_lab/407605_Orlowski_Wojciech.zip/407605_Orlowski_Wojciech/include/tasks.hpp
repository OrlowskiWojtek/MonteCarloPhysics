#ifndef TASKS_HPP
#define TASKS_HPP

#include <vector>
#include <cmath>

void task_1();
void task_2();

#endif