#include <iostream>
#include "photon_difussion.hpp"
#include "utils.hpp"

int main()
{
    task_2();
    task_3();

    return 0;
}


